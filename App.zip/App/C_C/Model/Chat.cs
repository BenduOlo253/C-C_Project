﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C_C.Model
{
    public class Chat
    {
        public int IdChat { get; set; }
        public int IdMatch { get; set; }
        public DateTime FechaInicioChat { get; set; }
    }
}
