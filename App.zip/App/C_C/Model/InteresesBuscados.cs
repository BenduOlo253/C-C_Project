﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C_C.Model
{
    public class InteresesBuscados
    {
        public int IdInteresesBuscados { get; set; }
        public int IdPreferencias { get; set; }
    }
}
