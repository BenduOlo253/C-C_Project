﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace C_C.Model
{
    public class Perfil 
    {
        public int IdPerfil { get; set; }
        public string NikName { get; set; }
        public Image FotoPerfil { get; set; }
        public string Biografia { get; set; }
    }
}
