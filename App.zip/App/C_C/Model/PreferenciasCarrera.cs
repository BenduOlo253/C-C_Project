﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C_C.Model
{
     public class PreferenciasCarrera
    {
        public int IdPreferencia { get; set; }
        public int IdCarrera { get; set; }
    }
}
